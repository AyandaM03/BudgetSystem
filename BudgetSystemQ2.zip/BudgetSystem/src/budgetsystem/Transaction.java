package budgetsystem;

import java.util.*;

public class Transaction {

    protected String description;
    protected double amount;
    protected String date;

    // Constructor for initializing transaction details
    public Transaction(String description, double amount, String date) {
        this.description = description;
        this.amount = amount;
        this.date = date;
    }

    // Get transaction details (useful for displaying in the report)
    public String getDetails() {
        return "Date: " + date + ", Description: " + description + ", Amount: " + amount;
    }

    public double getAmount() {
        return amount;
    }
}