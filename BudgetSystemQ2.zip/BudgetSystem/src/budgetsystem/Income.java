
package budgetsystem;


public class Income extends Transaction {
 
      // Constructor for Income
     public Income(String description, double amount, String date) {
        super(description, amount, date);
    }
}

