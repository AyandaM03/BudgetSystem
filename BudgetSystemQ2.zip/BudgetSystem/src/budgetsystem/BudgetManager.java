package budgetsystem;


public class BudgetManager {
  
        private Transaction[] transactions;
    private int transactionCount;
    private double totalIncome;
    private double totalExpense;

    // Constructor to initialize the budget manager
    public BudgetManager(int maxTransactions) {
        transactions = new Transaction[maxTransactions];
        transactionCount = 0;
        totalIncome = 0.0;
        totalExpense = 0.0;
    }

     // Method to add an income
    public void addIncome(String description, double amount, String date) {
        transactions[transactionCount++] = new Income(description, amount, date);
        totalIncome += amount;
        System.out.println("Income added successfully.");
    }

    // Method to add an expense
    public void addExpense(String description, double amount, String date) {
        transactions[transactionCount++] = new Expense(description, amount, date);
        totalExpense += amount;
        System.out.println("Expense added successfully.");
    }

    // Method to calculate the current balance
    public double calculateBalance() {
        return totalIncome - totalExpense;
    }
    
        // Method to generate a report
    public void generateReport() {
        System.out.println("\n--- Budget Report ---");
        System.out.println("Total Income: " + totalIncome);
        System.out.println("Total Expense: " + totalExpense);
        System.out.println("Current Balance: " + calculateBalance());
        System.out.println("\nDetailed Transactions:");

        for (int i = 0; i < transactionCount; i++) {
            System.out.println(transactions[i].getDetails());
        }
        System.out.println("----------------------");
    }
}

