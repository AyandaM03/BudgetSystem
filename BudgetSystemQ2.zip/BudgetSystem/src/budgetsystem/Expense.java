
package budgetsystem;


public class Expense extends Transaction {
  
     // Constructor for Expense
    public Expense(String description, double amount, String date) {
        super(description, amount, date);
    }
}

