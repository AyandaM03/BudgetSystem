package budgetsystem;

import java.util.*;


public class BudgetApp {
    
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BudgetManager budgetManager = new BudgetManager(100);  // Allow up to 100 transactions

        boolean running = true;

        while (running) {
            System.out.println("\nBudget Management System");
            System.out.println("1. Add Income");
            System.out.println("2. Add Expense");
            System.out.println("3. View Current Balance");
            System.out.println("4. Generate Budget Report");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Clear the input buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter income description: ");
                    String incomeDesc = scanner.nextLine();
                    System.out.print("Enter income amount: ");
                    double incomeAmount = scanner.nextDouble();
                    scanner.nextLine();  // Clear buffer
                    System.out.print("Enter income date (YYYY-MM-DD): ");
                    String incomeDate = scanner.nextLine();
                    budgetManager.addIncome(incomeDesc, incomeAmount, incomeDate);
                    break;
                    
                      case 2:
                    System.out.print("Enter expense description: ");
                    String expenseDesc = scanner.nextLine();
                    System.out.print("Enter expense amount: ");
                    double expenseAmount = scanner.nextDouble();
                    scanner.nextLine();  // Clear buffer
                    System.out.print("Enter expense date (YYYY-MM-DD): ");
                    String expenseDate = scanner.nextLine();
                    budgetManager.addExpense(expenseDesc, expenseAmount, expenseDate);
                    break;

                case 3:
                    System.out.println("Current Balance: " + budgetManager.calculateBalance());
                    break;

                case 4:
                    budgetManager.generateReport();
                    break;

                case 5:
                    running = false;
                    System.out.println("Exiting the application...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}

